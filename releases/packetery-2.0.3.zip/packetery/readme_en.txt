First of all register at http://client.packeta.com/ and copypast API password to its field on module tab.

All settings autosaves.

To add new packetery carrier please click "+" button in top right corner of "PACKETERY CARRIERS" table

Associate Packetery Address delivery services with prestashop carriers(if needed)

You can change carrier and payment COD setting by clicking on it. All COD settings in tables is clickable.

Branch name in orders table is clickable. So you can change branch after order placed.

Branches autoupdating every night.

Tab Branches total is autoupdating (you dont need to reload page).

If you use multistore function eshop field autofills with current shop of your admin panel

To export packets and create shiment choose Zasilkovna associated orders and click "Export selected orders and create shipment"

To print labels choose exported Zasilkovna associated orders and click "Download pdf labels"

Have a nice day