
Najskôr sa zaregistrujte na http://client.packeta.com/ a nakopírujte API heslo do poľa na karte modulu.

Všetky nastavenia sa ukladajú automaticky.

Ak chcete pridať nového Packetery prepravcu, kliknite na tlačidlo "+" v pravom hornom rohu tabuľky "PACKETERY PREPRAVCI"

Združené služby Packetery Adresa doručovacie služby s prestashop dopravcovi (v prípade potreby)

Môžete zmeniť nastavenie dopravcu a platby COD pomocou tlačidla. Na všetky nastavenia COD v tabuľkách sa dá kliknúť.

Na všetky názvy pobočiek v tabuľkách sa dá kliknúť. Takže môžete zmeniť poradie pobočiek.

Pobočky sa automaticky aktualizujú každú noc.

Celkový počet počet pobočiek sa automaticky aktualizuje (nemusíte stránku znovu načítať).

Ak používate automatické dopĺňanie s viacerými obchodmi v e-shopu s aktuálnou predajňou na administračnom panelu

Ak chcete exportovať balíky a vytvoriť zásielky, vyberte príkazy pridružené k Zasilkovna a kliknite na tlačidlo "Export vybraných objednávok a vytvorenie zásielky"

Ak chcete vytlačiť štítky, vyberte exportované objednávky spojené s Zasilkovna a kliknite na tlačidlo "Stiahnuť etikety v pdf"

Pekný deň