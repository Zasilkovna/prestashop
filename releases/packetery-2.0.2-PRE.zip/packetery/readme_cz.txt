Nejprve se zaregistrujte na http://client.packeta.com/ a zkopírujte API heslo do pole na kartě modulu.

Všechna nastavení se automaticky ukládají.

Pro přidání nového doručovatele Zásilkovna, prosím použijte tlačítko "+" v pravém horním rohu tabulky "Přidání způsobu dopravy"

Sdružené služby Packetery Adresa doručovací služby s prestashop dopravci (v případě potřeby)

Můžete změnit nastavení dopravce a platby COD pomocí tlačítka. Na všechna nastavení COD v tabulkách lze kliknout.

Na název výdejního místa v tabulkách objednávek je možné kliknout. Takže můžete změnit pořadí poboček.

Výdejní místa se automaticky aktualizují každou noc.

Sekce "Celkem poboček" se automaticky aktualizuje ( není třeba obnovovat stránku )

Pokud používáte Multistore, políčka eshopu se automaticky vyplní aktuálním názvem obchodu, který je nastaven v administrátorském panelu.

Chcete-li exportovat balíčky a vytvořit zásilky, zvolte příkazy přidružené k Zasilkovna a klikněte na tlačítko "Export vybraných objednávek a vytvoření zásilky"

Chcete-li vytisknout štítky, zvolte exportované objednávky spojené s Zasilkovnou a klikněte na tlačítko "Stáhnout etikety s pdf"

Hezký den přeje Zásilkovna