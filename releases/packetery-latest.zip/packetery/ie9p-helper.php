<?php
  @header("Content-Type: application/javascript; charset=utf-8");
  @header("Cache-Control: ");
  @header("Expires: ");
  @header("Pragma: ");
  echo $_GET['call'];
?>();